# Visualization Parameter Contract

The Vib3 shader systems now share a common parameter contract so quaternion-driven
pipelines can target the faceted, quantum, and holographic renderers with a single
update path.

## Interface Overview

| Method | Purpose |
| --- | --- |
| `updateParameter(name, value, context?)` | Apply a single parameter change. Implementations accept an optional context payload describing the source of the update. |
| `batchUpdate(updates, context?)` | Apply a set of parameter changes atomically. Implementations should prefer this path when available to minimize GPU uniform churn. |

The context payload is passed straight through from the quaternion synchronizer and includes:

- `confidence` – weighted confidence hint from XR pose data.
- `motionEnergy` – smoothed angular velocity derived from quaternion deltas.
- `timestamp` and `source` – timing and origin metadata for profiling.
- `euler`/`quaternion`/`uniforms` – the orientation math already prepared for shaders.
- `rotationUniforms` – precomputed six-plane data including a column-major 4×4 rotation matrix, a top-left 3×3 slice for
  projection work, and the raw plane angles so GPU and compute pipelines can rehydrate full SO(4) transforms without
  recalculating sine/cosine per fragment.
- `parameters` – per-parameter lerp metadata (`current`, `target`, and `alpha`).

Rotation-specific payloads now always contain the full six-plane set (`rot4dXY`, `rot4dXZ`, `rot4dYZ`, `rot4dXW`, `rot4dYW`, `rot4dZW`) so downstream systems can perform double-sided quaternion rotations without guessing missing axes.

Geometry selections travel alongside the rotation bundle as well:

- `geometry` – encoded geometry index (0-23) combining base shape and core variant.
- `geometryBase` – base geometry index (tetrahedron, hypercube, sphere, torus, Klein bottle, fractal, wave, crystal).
- `geometryCore` – core variant index (`0 = hypercube core`, `1 = hypersphere core`, `2 = hypertetra core`).

`ParameterManager` keeps these three values synchronized so consumers can rely on either the encoded value or the discrete base/core indices.【F:src/core/Parameters.js†L8-L126】 Each geometry variation now ships with a rotation profile that pre-seeds the six-plane angles and dimensional bias based on the chosen core (legacy hypercube, hypersphere, hypertetra). Emphasised planes inherit stronger magnitudes while non-emphasised planes retain a gentler baseline so downstream systems can immediately render a core-appropriate pose without guesswork.【F:src/vib3plus/Vib3PlusGeometryTree.js†L1-L118】【F:src/vib3plus/Vib3PlusGeometryTree.js†L120-L161】

When a system needs to swap geometries using semantic identifiers instead of raw indices, `GeometryLibrary.resolveGeometryIndex()` now converts base/core keys into the encoded value and `GeometryLibrary.describeByComponents()` returns the accompanying metadata payload.【F:src/geometry/GeometryLibrary.js†L1-L126】 `Vib3PlusEnvironment.applyGeometryComponents()` wraps this helper so callers can select shapes declaratively and immediately receive the associated rotation profile in the broadcast context for synchronized shader updates.【F:src/vib3plus/Vib3PlusEnvironment.js†L1-L197】

## Producer Responsibilities

`ShaderQuaternionSynchronizer` gathers lerped parameter values, attaches the context
metadata, and prefers `batchUpdate` when systems expose it, falling back to
`updateParameter` when necessary.【F:src/ui/adaptive/renderers/ShaderQuaternionSynchronizer.js†L248-L358】

## Consumer Implementations

- **QuantumEngine** normalizes incoming updates, clamps via `ParameterManager`, and
  pushes a single object into every quantum visualizer so each GPU layer stays in
  sync.【F:src/quantum/QuantumEngine.js†L163-L193】【F:src/quantum/QuantumEngine.js†L268-L347】
- **RealHolographicSystem** records persistent overrides, calls into each layer’s
  `updateParameters` method when available, and gracefully falls back to legacy
  visualizers that only support direct property writes.【F:src/holograms/RealHolographicSystem.js†L151-L220】
- **Visualizer / QuantumVisualizer / HolographicVisualizer** now accept the optional
  `context` argument so downstream consumers can opt into richer telemetry without
  altering existing behavior.【F:src/core/Visualizer.js†L525-L531】【F:src/quantum/QuantumVisualizer.js†L838-L841】【F:src/holograms/HolographicVisualizer.js†L862-L911】

## Usage Pattern

```js
// Synchronizer side (already implemented)
const context = { confidence: 0.82, motionEnergy: 0.48, systemName: 'quantum' };
quantumSystem.batchUpdate({
  rot4dXY: -0.08,
  rot4dXZ: 0.12,
  rot4dYZ: -0.04,
  rot4dXW: -0.16,
  rot4dYW: 0.48,
  rot4dZW: 0.32,
  chaos: 0.40,
  intensity: 0.86
}, context);
```

```js
// Renderer side (QuantumEngine)
updateParameter(name, value, context) {
  this.batchUpdate({ [name]: value }, context);
}
```

The shared contract keeps quaternion-driven updates coherent, reduces duplicate
math, and exposes the rich context metadata that later telemetry and profiling
phases will consume.
